"""
PRACTICAL 10: Mini Case Study and Dashboard
Aim: Analyze a sales decline, clean data, perform EDA and create dashboard charts.
"""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.DataFrame([
    ["01-01-2024","North","Electronics",142000,21000,5,98],
    ["01-02-2024","North","Electronics",138000,19500,5,99],
    ["01-03-2024","North","Electronics",129000,17000,8,102],
    ["01-04-2024","North","Electronics",118000,15000,8,105],
    ["01-05-2024","North","Electronics",109000,13000,10,108],
    ["01-06-2024","North","Electronics",101000,11500,10,110],
    ["01-01-2024","South","Apparel",49000,6000,5,97],
    ["01-02-2024","South","Apparel",47000,5800,5,98],
    ["01-03-2024","South","Apparel",44000,5200,7,100],
    ["01-04-2024","South","Apparel",40000,4500,7,103]
], columns=["Date","Region","Product","SalesAmount","AdSpend","DiscountPercent","CompetitorPriceIndex"])

# Data cleaning
df = df.drop_duplicates().copy()
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, errors="coerce")
df["Region"] = df["Region"].astype(str).str.title()
df["Product"] = df["Product"].astype(str).str.title()
for col in ["SalesAmount","AdSpend","DiscountPercent","CompetitorPriceIndex"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")
for col in ["SalesAmount","AdSpend","DiscountPercent","CompetitorPriceIndex"]:
    df[col] = df.groupby(["Region","Product"])[col].transform(lambda s: s.fillna(s.median()))

df.to_csv("case_study_cleaned.csv", index=False)
monthly = df.groupby(df["Date"].dt.strftime("%b"))["SalesAmount"].sum()
print("Total Sales:", df["SalesAmount"].sum())
print("Average Discount %:", df["DiscountPercent"].mean())
print("\nCorrelation matrix:\n", df[["SalesAmount","AdSpend","DiscountPercent","CompetitorPriceIndex"]].corr())
print("\nSales by Region and Product:\n", df.groupby(["Region","Product"])["SalesAmount"].sum())

plt.figure()
monthly.plot(kind="line", marker="o")
plt.title("Northwind Retail - Monthly Sales Trend")
plt.xlabel("Month"); plt.ylabel("Sales Amount (₹)")
plt.tight_layout(); plt.savefig("practical_10_monthly_sales.png")

plt.figure()
df.groupby(["Region","Product"])["SalesAmount"].sum().plot(kind="bar")
plt.title("Sales by Region and Product")
plt.xlabel("Region / Product"); plt.ylabel("Sales Amount (₹)")
plt.tight_layout(); plt.savefig("practical_10_region_product.png")
plt.show()

print("\nRecommendations:")
print("1. Review and restore advertising investment where sales fell alongside ad spend.")
print("2. Review product pricing against competitor price changes.")
print("3. Use customer segmentation to plan targeted regional campaigns.")

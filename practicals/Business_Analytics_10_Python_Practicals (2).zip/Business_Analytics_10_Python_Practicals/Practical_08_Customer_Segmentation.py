"""
PRACTICAL 8: Customer Segmentation using K-Means Clustering
Aim: Group customers based on annual income and spending score.
"""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df = pd.DataFrame({
    "CustomerID":["C001","C002","C003","C004","C005","C006","C007","C008","C009","C010","C011","C012"],
    "AnnualIncome":[250,270,180,190,95,88,60,55,260,75,100,185],
    "SpendingScore":[82,88,25,18,75,80,22,30,90,20,78,22]
})
features = df[["AnnualIncome","SpendingScore"]]
scaled = StandardScaler().fit_transform(features)

# Elbow method for k=1 to 6
inertias = []
for k in range(1, 7):
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(scaled)
    inertias.append(model.inertia_)
print("Within-cluster sum of squares:", dict(zip(range(1,7), inertias)))

# Journal profiles the customer groups with k=3.
model = KMeans(n_clusters=3, random_state=42, n_init=10)
df["Cluster"] = model.fit_predict(scaled)
profile = df.groupby("Cluster").agg(
    Customers=("CustomerID","count"),
    AverageIncome=("AnnualIncome","mean"),
    AverageSpending=("SpendingScore","mean")
)
print("\nCustomer assignments:\n", df)
print("\nCluster profiles:\n", profile)

plt.figure()
for cluster, group in df.groupby("Cluster"):
    plt.scatter(group["AnnualIncome"], group["SpendingScore"], label=f"Cluster {cluster}")
plt.title("Customer Segments")
plt.xlabel("Annual Income (₹'000)"); plt.ylabel("Spending Score")
plt.legend(); plt.tight_layout()
plt.savefig("practical_08_customer_clusters.png")
plt.show()

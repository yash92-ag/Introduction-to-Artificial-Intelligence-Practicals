"""
PRACTICAL 7: Forecasting using Moving Average and Exponential Smoothing
Aim: Forecast monthly sales and compare forecast accuracy.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

months = ["Jan-2024","Feb-2024","Mar-2024","Apr-2024","May-2024","Jun-2024",
          "Jul-2024","Aug-2024","Sep-2024","Oct-2024","Nov-2024","Dec-2024"]
sales = pd.Series([210000,198000,225000,240000,232000,251000,
                   264000,258000,270000,285000,298000,310000], index=months)

ma3 = sales.shift(1).rolling(3).mean()
ma6 = sales.shift(1).rolling(6).mean()

alpha = 0.3
ses = pd.Series(index=sales.index, dtype=float)
ses.iloc[0] = np.nan
forecast = sales.iloc[0]
for i in range(1, len(sales)):
    ses.iloc[i] = forecast
    forecast = alpha * sales.iloc[i] + (1-alpha) * forecast

def accuracy(actual, predicted):
    valid = predicted.notna()
    errors = actual[valid] - predicted[valid]
    return errors.abs().mean(), np.sqrt((errors**2).mean())

print(pd.DataFrame({"Actual":sales, "MA_3":ma3, "MA_6":ma6, "SES":ses}).round(2))
for name, forecast_series in [("3-Month MA",ma3),("6-Month MA",ma6),("SES",ses)]:
    mae, rmse = accuracy(sales, forecast_series)
    print(f"{{name}}: MAE={{mae:,.2f}}, RMSE={{rmse:,.2f}}")

plt.figure()
plt.plot(sales.index, sales.values, marker="o", label="Actual")
plt.plot(ma3.index, ma3.values, marker="o", label="3-Month MA")
plt.plot(ma6.index, ma6.values, marker="o", label="6-Month MA")
plt.plot(ses.index, ses.values, marker="o", label="SES")
plt.title("Monthly Sales Forecast Comparison")
plt.xlabel("Month"); plt.ylabel("Sales (₹)")
plt.xticks(rotation=45); plt.legend(); plt.tight_layout()
plt.savefig("practical_07_forecast.png")
plt.show()

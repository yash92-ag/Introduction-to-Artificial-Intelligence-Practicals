"""
PRACTICAL 2: Descriptive Statistics on Business Data
Aim: Calculate central tendency, dispersion and distribution shape.
"""
import pandas as pd
import numpy as np

income = pd.Series([42000,46500,55000,38000,95000,61000,52000,44000,48000,49000,53000,41000],
                   name="MonthlyIncome")
summary = {
    "Count": income.count(),
    "Mean": income.mean(),
    "Median": income.median(),
    "Mode": income.mode().tolist(),
    "Variance": income.var(),
    "Standard Deviation": income.std(),
    "Range": income.max() - income.min(),
    "Minimum": income.min(),
    "Maximum": income.max(),
    "Q1": income.quantile(0.25),
    "Q2 (Median)": income.quantile(0.50),
    "Q3": income.quantile(0.75),
    "IQR": income.quantile(0.75) - income.quantile(0.25),
    "Skewness": income.skew(),
    "Kurtosis": income.kurt()
}
print("DESCRIPTIVE STATISTICS")
for key, value in summary.items():
    print(f"{key}: {value}")
print("\nBusiness interpretation: compare mean and median to understand skewness;")
print("standard deviation and IQR show how widely employee incomes vary.")

try:
    import matplotlib.pyplot as plt
    plt.figure()
    plt.hist(income, bins=7, edgecolor="black")
    plt.title("Monthly Income Distribution")
    plt.xlabel("Monthly Income (₹)")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig("practical_02_income_histogram.png")
    plt.show()
except ImportError:
    print("Install matplotlib to create the histogram.")

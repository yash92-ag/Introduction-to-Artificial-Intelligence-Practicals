"""
PRACTICAL 3: Pivot Tables and Cross-Tabulation
Aim: Summarize sales by region and by product-year.
"""
import pandas as pd

rows = [
    ['S101','North','Electronics',2023,'Jan',125000,18000],
    ['S102','North','Apparel',2023,'Jan',64000,9000],
    ['S103','South','Electronics',2023,'Jan',58000,7000],
    ['S104','East','Apparel',2023,'Feb',71000,9500],
    ['S105','West','Electronics',2023,'Feb',98000,14000],
    ['S106','North','Electronics',2024,'Jan',142000,21000],
    ['S107','South','Apparel',2024,'Jan',49000,6000],
    ['S108','South','Electronics',2024,'Feb',51000,6500],
    ['S109','East','Electronics',2024,'Feb',87000,12000],
    ['S110','North','Apparel',2024,'Mar',69000,9800],
    ['S111','West','Apparel',2023,'Mar',56000,7200],
    ['S112','West','Electronics',2024,'Mar',102000,15500],
    ['S113','East','Apparel',2024,'Apr',73000,9700],
    ['S114','South','Electronics',2023,'Apr',53000,6800]
]
df = pd.DataFrame(rows, columns=["OrderID","Region","Product","Year","Month","SalesAmount","AdSpend"])

region_pivot = pd.pivot_table(df, index="Region", values="SalesAmount", aggfunc="sum", margins=True)
product_year = pd.pivot_table(df, index="Product", columns="Year", values="SalesAmount",
                              aggfunc="sum", fill_value=0, margins=True)
print("TOTAL SALES BY REGION\n", region_pivot)
print("\nSALES BY PRODUCT AND YEAR\n", product_year)

# Product slicer equivalent: filter data to Electronics.
electronics = df[df["Product"] == "Electronics"]
print("\nREGIONAL SALES - ELECTRONICS ONLY\n",
      electronics.groupby("Region")["SalesAmount"].sum())

print("\nBusiness insights:")
print("1. North has the highest regional sales.")
print("2. Electronics contributes more sales than Apparel.")
print("3. Compare regional product totals to identify weaker markets.")

region_pivot.to_csv("practical_03_sales_by_region.csv")
product_year.to_csv("practical_03_product_year.csv")

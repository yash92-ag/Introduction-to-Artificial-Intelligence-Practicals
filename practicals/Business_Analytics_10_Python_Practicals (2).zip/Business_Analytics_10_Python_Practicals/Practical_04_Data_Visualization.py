"""
PRACTICAL 4: Data Visualization - Charts and Plots
Aim: Create column, line, pie, scatter and box plots from sales data.
"""
import pandas as pd
import matplotlib.pyplot as plt

rows = [
    ['S101','North','Electronics',2023,'Jan',125000,18000],
    ['S102','North','Apparel',2023,'Jan',64000,9000],
    ['S103','South','Electronics',2023,'Jan',58000,7000],
    ['S104','East','Apparel',2023,'Feb',71000,9500],
    ['S105','West','Electronics',2023,'Feb',98000,14000],
    ['S106','North','Electronics',2024,'Jan',142000,21000],
    ['S107','South','Apparel',2024,'Jan',49000,6000],
    ['S108','South','Electronics',2024,'Feb',51000,6500],
    ['S109','East','Electronics',2024,'Feb',87000,12000],
    ['S110','North','Apparel',2024,'Mar',69000,9800],
    ['S111','West','Apparel',2023,'Mar',56000,7200],
    ['S112','West','Electronics',2024,'Mar',102000,15500],
    ['S113','East','Apparel',2024,'Apr',73000,9700],
    ['S114','South','Electronics',2023,'Apr',53000,6800]
]
df = pd.DataFrame(rows, columns=["OrderID","Region","Product","Year","Month","SalesAmount","AdSpend"])

region = df.groupby("Region")["SalesAmount"].sum().sort_index()
monthly = df.groupby("Month")["SalesAmount"].sum().reindex(["Jan","Feb","Mar","Apr"])
product = df.groupby("Product")["SalesAmount"].sum()

plt.figure()
region.plot(kind="bar")
plt.title("Total Sales by Region")
plt.xlabel("Region"); plt.ylabel("Sales Amount (₹)")
plt.tight_layout(); plt.savefig("practical_04_region_sales.png")

plt.figure()
monthly.plot(kind="line", marker="o")
plt.title("Monthly Sales Trend")
plt.xlabel("Month"); plt.ylabel("Sales Amount (₹)")
plt.tight_layout(); plt.savefig("practical_04_monthly_trend.png")

plt.figure()
product.plot(kind="pie", autopct="%1.1f%%")
plt.title("Product Share of Total Sales")
plt.ylabel("")
plt.tight_layout(); plt.savefig("practical_04_product_share.png")

plt.figure()
plt.scatter(df["AdSpend"], df["SalesAmount"])
plt.title("Advertising Spend vs Sales")
plt.xlabel("Ad Spend (₹)"); plt.ylabel("Sales Amount (₹)")
plt.tight_layout(); plt.savefig("practical_04_scatter.png")

plt.figure()
df.boxplot(column="SalesAmount", by="Region")
plt.title("Sales Distribution by Region")
plt.suptitle("")
plt.xlabel("Region"); plt.ylabel("Sales Amount (₹)")
plt.tight_layout(); plt.savefig("practical_04_boxplot.png")

print("Chart files saved in the current folder.")
print("\nChart use: Column=category comparison; Line=time trend; Pie=share;")
print("Scatter=relationship between numeric variables; Boxplot=spread and outliers.")
plt.show()

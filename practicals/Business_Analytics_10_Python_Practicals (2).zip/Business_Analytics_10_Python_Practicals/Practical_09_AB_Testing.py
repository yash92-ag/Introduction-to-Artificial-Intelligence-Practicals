"""
PRACTICAL 9: A/B Testing on Marketing Data
Aim: Test whether Campaign B conversion rate is statistically higher than Campaign A.
"""
import pandas as pd
from statsmodels.stats.proportion import proportions_ztest

df = pd.DataFrame({
    "UserID":[f"U{i:03d}" for i in range(1,17)],
    "Group":["A"]*8 + ["B"]*8,
    "Converted":[0,1,0,0,1,0,0,1, 1,1,0,1,1,0,1,1]
})
summary = df.groupby("Group")["Converted"].agg(["sum","count","mean"])
print("Campaign summary:\n", summary)
successes = summary["sum"].to_numpy()
totals = summary["count"].to_numpy()
z_stat, p_value = proportions_ztest(successes, totals, alternative="two-sided")

print(f"Conversion rate A: {{summary.loc['A','mean']:.1%}}")
print(f"Conversion rate B: {{summary.loc['B','mean']:.1%}}")
print(f"Z statistic: {{z_stat:.4f}}")
print(f"Two-tailed p-value: {{p_value:.4f}}")

alpha = 0.05
if p_value < alpha:
    print("Result: statistically significant difference at 95% confidence.")
    print("Recommendation: investigate and consider adopting the better-performing campaign.")
else:
    print("Result: not statistically significant at the 95% confidence level.")
    print("Recommendation: extend the test or increase sample size before rollout.")

BUSINESS ANALYTICS - 10 PYTHON PRACTICALS

These 10 .py files are prepared from the uploaded Introduction to Business Analytics Lab journal.
The scripts use the sample data shown in the journal, so they can run without separate CSV files
(except Practical 1, which uses the journal sample if hr_data.csv is not present).

Install required libraries:
    pip install pandas numpy matplotlib scikit-learn scipy statsmodels

Run a practical:
    python Practical_01_Data_Import_and_Cleaning.py

Notes:
- Practical 1 can optionally read hr_data.csv from the same folder.
- Output CSV files and chart PNG files are saved in the same folder.
- These are Python implementations of the journal practicals, not a page-for-page PDF conversion.

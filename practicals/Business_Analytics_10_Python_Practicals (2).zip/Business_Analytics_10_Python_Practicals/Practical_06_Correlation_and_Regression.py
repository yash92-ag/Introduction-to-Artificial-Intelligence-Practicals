"""
PRACTICAL 6: Correlation and Simple Linear Regression
Aim: Measure the relationship between AdSpend and SalesAmount and predict sales.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import linregress

rows = [
    ['S101','North','Electronics',2023,'Jan',125000,18000],
    ['S102','North','Apparel',2023,'Jan',64000,9000],
    ['S103','South','Electronics',2023,'Jan',58000,7000],
    ['S104','East','Apparel',2023,'Feb',71000,9500],
    ['S105','West','Electronics',2023,'Feb',98000,14000],
    ['S106','North','Electronics',2024,'Jan',142000,21000],
    ['S107','South','Apparel',2024,'Jan',49000,6000],
    ['S108','South','Electronics',2024,'Feb',51000,6500],
    ['S109','East','Electronics',2024,'Feb',87000,12000],
    ['S110','North','Apparel',2024,'Mar',69000,9800],
    ['S111','West','Apparel',2023,'Mar',56000,7200],
    ['S112','West','Electronics',2024,'Mar',102000,15500],
    ['S113','East','Apparel',2024,'Apr',73000,9700],
    ['S114','South','Electronics',2023,'Apr',53000,6800]
]
df = pd.DataFrame(rows, columns=["OrderID","Region","Product","Year","Month","SalesAmount","AdSpend"])
x = df["AdSpend"]
y = df["SalesAmount"]
result = linregress(x, y)

print("Correlation:", x.corr(y))
print(f"Regression equation: Sales = {result.intercept:.2f} + {result.slope:.4f} * AdSpend")
print(f"R-squared: {result.rvalue**2:.4f}")
for spend in [20000, 30000]:
    prediction = result.intercept + result.slope * spend
    print(f"Predicted sales for ad spend ₹{spend:,}: ₹{prediction:,.2f}")

plt.figure()
plt.scatter(x, y, label="Actual data")
plt.plot(x, result.intercept + result.slope*x, label="Regression line")
plt.title("Advertising Spend vs Sales")
plt.xlabel("Ad Spend (₹)"); plt.ylabel("Sales Amount (₹)")
plt.legend(); plt.tight_layout()
plt.savefig("practical_06_regression.png")
plt.show()

"""
PRACTICAL 5: Exploratory Data Analysis (EDA)
Aim: Perform univariate, bivariate and grouped analysis.
"""
import pandas as pd
import matplotlib.pyplot as plt

rows = [
    ['S101','North','Electronics',2023,'Jan',125000,18000],
    ['S102','North','Apparel',2023,'Jan',64000,9000],
    ['S103','South','Electronics',2023,'Jan',58000,7000],
    ['S104','East','Apparel',2023,'Feb',71000,9500],
    ['S105','West','Electronics',2023,'Feb',98000,14000],
    ['S106','North','Electronics',2024,'Jan',142000,21000],
    ['S107','South','Apparel',2024,'Jan',49000,6000],
    ['S108','South','Electronics',2024,'Feb',51000,6500],
    ['S109','East','Electronics',2024,'Feb',87000,12000],
    ['S110','North','Apparel',2024,'Mar',69000,9800],
    ['S111','West','Apparel',2023,'Mar',56000,7200],
    ['S112','West','Electronics',2024,'Mar',102000,15500],
    ['S113','East','Apparel',2024,'Apr',73000,9700],
    ['S114','South','Electronics',2023,'Apr',53000,6800]
]
df = pd.DataFrame(rows, columns=["OrderID","Region","Product","Year","Month","SalesAmount","AdSpend"])
numeric = df[["SalesAmount","AdSpend"]]

print("UNIVARIATE DESCRIPTIVE STATISTICS\n", numeric.describe().T)
print("\nCORRELATION MATRIX\n", numeric.corr())
print("\nGROUP SUMMARY: REGION AND PRODUCT\n",
      df.groupby(["Region","Product"])["SalesAmount"].agg(["mean","sum","count"]))

# Month index correlation
month_map = {"Jan":1,"Feb":2,"Mar":3,"Apr":4}
df["MonthIndex"] = df["Month"].map(month_map)
print("\nAdSpend vs Sales correlation:", df["AdSpend"].corr(df["SalesAmount"]))
print("Month index vs Sales correlation:", df["MonthIndex"].corr(df["SalesAmount"]))

plt.figure()
plt.hist(df["SalesAmount"], bins=6, edgecolor="black")
plt.title("Sales Amount Histogram")
plt.xlabel("Sales Amount (₹)"); plt.ylabel("Frequency")
plt.tight_layout(); plt.savefig("practical_05_sales_histogram.png")

plt.figure()
corr = numeric.corr()
plt.imshow(corr, vmin=-1, vmax=1)
plt.colorbar()
plt.xticks(range(len(corr.columns)), corr.columns, rotation=20)
plt.yticks(range(len(corr.index)), corr.index)
for i in range(len(corr.index)):
    for j in range(len(corr.columns)):
        plt.text(j, i, f"{corr.iloc[i,j]:.3f}", ha="center", va="center")
plt.title("Correlation Heatmap")
plt.tight_layout(); plt.savefig("practical_05_correlation_heatmap.png")
plt.show()

print("\nEDA insights: review the strongest correlation, highest-sales region,")
print("product contribution, distribution shape and weaker region/product groups.")

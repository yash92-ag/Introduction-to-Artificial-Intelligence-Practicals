"""
PRACTICAL 1: Data Import & Cleaning
Aim: Import a raw HR dataset, inspect data quality and create a cleaned dataset.
Run: python Practical_01_Data_Import_and_Cleaning.py
Optional: place hr_data.csv in this folder to use your own data.
"""
import pandas as pd
import numpy as np

sample = [
    ['E001','Aarav Shah','sales',29,'M',42000,'12-03-2021','No'],
    ['E002','Priya Nair','Sales',34,'F',np.nan,'05-07-2019','No'],
    ['E003','Rohit Verma','HR',41,'M',55000,'22-11-2018','Yes'],
    ['E004','Rohit Verma','HR',41,'M',55000,'22-11-2018','Yes'],
    ['E005','Sneha Iyer','finance',26,'F',38000,'15-01-2022','No'],
    ['E006','Kunal Mehta','Finance',38,'M',950000,'30-06-2017','No'],
    ['E007',None,'Marketing',31,'F',47000,'09-09-2020','No'],
    ['E008','Divya Rao','sales',45,'F',61000,'14-02-2016','Yes'],
    ['E009','Arjun Singh','IT',27,'M',52000,'2021/08/19','No'],
    ['E010','Meena Kumar','Marketing',33,'F',44000,'03-12-2019','No'],
    ['E011','Aditya Joshi','IT',29,'M',np.nan,'25-04-2021','No'],
    ['E012','Kavya Reddy','finance',36,'F',49000,'11-10-2018','No']
]
columns = ['EmployeeID','Name','Department','Age','Gender','MonthlyIncome','JoiningDate','AttritionFlag']
if __.path__ if False else False: pass
try:
    df = pd.read_csv("hr_data.csv")
    print("Loaded hr_data.csv")
except FileNotFoundError:
    df = pd.DataFrame(sample, columns=columns)
    print("Using sample data from the practical journal.")

print("\nOriginal shape:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())

# Identify income outliers using the IQR method (flag, do not delete).
income = pd.to_numeric(df["MonthlyIncome"], errors="coerce")
q1, q3 = income.quantile([0.25, 0.75])
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
df["Income_Outlier_Flag"] = (income < lower) | (income > upper)

# Remove exact duplicate records.
df = df.drop_duplicates().copy()

# Fill missing income using the median of the employee's department.
df["MonthlyIncome"] = pd.to_numeric(df["MonthlyIncome"], errors="coerce")
for department, indexes in df[df["MonthlyIncome"].isna()].groupby("Department").groups.items():
    median_value = df.loc[df["Department"] == department, "MonthlyIncome"].median()
    df.loc[indexes, "MonthlyIncome"] = median_value

# Keep missing names visible and standardize text/date fields.
df["Name_Missing_Flag"] = df["Name"].isna()
df["Department"] = df["Department"].astype("string").str.title()
df["Gender"] = df["Gender"].astype("string").str.upper()
df["JoiningDate"] = pd.to_datetime(df["JoiningDate"], dayfirst=True, errors="coerce")

df.to_csv("hr_data_cleaned.csv", index=False)
print("\nCleaned shape:", df.shape)
print("\nCleaned data preview:\n", df.head())
print("\nSaved: hr_data_cleaned.csv")
